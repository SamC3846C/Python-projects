<?php
session_start();
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['Admin', 'Teacher', 'Student'])) {
    session_unset();
    session_destroy();
    header('Location: ../login/');
    exit;
}
$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACRGS</title>
    <link rel="stylesheet" href="../assets/css/dashboard-styles.css">
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var xhr = new XMLHttpRequest();
        var role = document.body.getAttribute('data-role');
        var url = '';
        if (role === 'Admin') {
            url = '../ajax/admin_dashboard_content.php';
        } else if (role === 'Teacher') {
            url = '../ajax/teacher_dashboard_content.php';
        } else if (role === 'Student') {
            url = '../ajax/student_dashboard_content.php';
        } else {
            window.location.href = '../login/';
            return;
        }
        xhr.open('GET', url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                document.getElementById('dashboard-content').innerHTML = xhr.responseText;
            }
        };
        xhr.send();
    });
    function signOut() {
        window.location.href = '../ajax/signout.php';
    }
    </script>
</head>
<body data-role="<?php echo htmlspecialchars($role); ?>">
    <div id="dashboard-content">
    </div>
</body>
</html>
