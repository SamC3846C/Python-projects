<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/admin-dashboard-styles.css">
</head>
<body>
    <div class="div-header">
        <span class="logo">
            <img src="../assets/images/banner-logo.jpeg" alt="DATIM Banner Logo">
        </span>
        <span class="head-title">
            Welcome Admin!
        </span>
    </div>
    <div class="div-main">
        <span class="span-sidebar" style="position:relative;">
            <a href="../admin/view_edit_databases.php">Database</a>
            <a href="../admin/generate_timetable.php">Time Table</a>
            <a href="../profile.php">Profile Settings</a>
            <span class="signout" onclick="signOut()">
                <span class="signout-text">Sign Out</span>
                <img src="../assets/images/sign_out.svg" name="signout" class="signout-btn" title="Sign Out"></img>
            </span>
        </span>
        <span class="span-main">
            <span class="heading">Generate Time Table</span>
            <hr>
            <span class="form-main">
                <span class="form-elements">
                <form action="generate.php" method="post">
                    <span class="select">
                        <label for="dept-select" class="dept-label">Select Dept</label>
                        <select name="dept-select" class="dept-select">
                            <option value="BCA">BCA</option>
                        </select>
                    </span>
                    <hr>
                    <span class="select">
                        <label for="sem-select" class="sem-label">Select Semester</label>
                        <select name="sem-select" class="sem-select">
                            <option value="Select Semester" hidden>Select Semester</option>
                        </select>
                    </span>
                    <hr>
                </form>
                <span class=gen-button>
                    <button class="generate-tt">Generate Time Table</button>
                </span>
                </span>
                <span class="side-image">
                    <img src="../assets/images/admin-dashboard.png" style="width:32vw">
                </span>
            </span>
        </span>
    </div>
</body>
</html>