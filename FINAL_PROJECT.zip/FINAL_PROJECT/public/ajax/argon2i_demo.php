<?php
// Argon2i encryption and verification demo
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $unencrypted = $_POST['unencrypted'] ?? '';
    $encrypted = $_POST['encrypted'] ?? '';
    $output = '';
    if ($action === 'encrypt' && $unencrypted !== '') {
        $hash = password_hash($unencrypted, PASSWORD_ARGON2I);
        $output = "<b>Encrypted String:</b> <br><textarea rows='3' cols='80'>" . htmlspecialchars($hash) . "</textarea>";
    } elseif ($action === 'verify' && $unencrypted !== '' && $encrypted !== '') {
        if (password_verify($unencrypted, $encrypted)) {
            $output = '<span style="color:green;">Match: The unencrypted string matches the encrypted hash.</span>';
        } else {
            $output = '<span style="color:red;">No Match: The unencrypted string does not match the encrypted hash.</span>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Argon2i Encrypt & Verify Demo</title>
</head>
<body>
    <h2>Argon2i String Encryption</h2>
    <form method="post">
        <label>String to Encrypt:</label><br>
        <input type="text" name="unencrypted" value="<?php echo isset($_POST['unencrypted']) ? htmlspecialchars($_POST['unencrypted']) : '' ?>" required><br><br>
        <button type="submit" name="action" value="encrypt">Encrypt</button>
    </form>
    <hr>
    <h2>Argon2i Verify</h2>
    <form method="post">
        <label>Unencrypted String:</label><br>
        <input type="text" name="unencrypted" required><br><br>
        <label>Encrypted String (Hash):</label><br>
        <textarea name="encrypted" rows="3" cols="80" required></textarea><br><br>
        <button type="submit" name="action" value="verify">Verify</button>
    </form>
    <hr>
    <?php if (!empty($output)) echo $output; ?>
</body>
</html>
