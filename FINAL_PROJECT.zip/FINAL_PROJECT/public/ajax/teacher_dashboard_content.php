<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/teacher-dashboard-styles.css">
</head>
<body>
    <div class="div-header">
        <span class="logo">
            <img src="../assets/images/banner-logo.jpeg" alt="Logo" />
        </span>
        <span class="head-title">
            Welcome Teacher!
        </span>
    </div>
    <div class="div-main">
        <span class="span-sidebar">
            <a href="#">My Schedule</a>
            <a href="#">View Profile</a>
            <a href="#">Time Table</a>
            <span class="signout" onclick="signOut()">
                <span class="signout-text">Sign Out</span>
                <img src="../assets/images/sign_out.svg" name="signout" class="signout-btn" title="Sign Out"></img>
            </span>
        </span>
        <span class="span-main">
            <span class="form-main">
                <span class="form-elements"></span>
                <span class="side-image">
                    <img src="../assets/images/teacher-dashboard.png" alt="Teacher Main Image">
                </span>
            </span>
        </span>
    </div>
</body>
</html>