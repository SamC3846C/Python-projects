<?php
session_start();
// Database connection
$host = 'localhost';
$db_user = 'sushii'; // change as needed
$db_pass = 'sushii123';    // change as needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $institution_id = isset($_POST['institution_id']) ? trim($_POST['institution_id']) : '';
    $role = isset($_POST['role']) ? trim($_POST['role']) : '';

    // Set session role on role select
    if ($role) {
        $_SESSION['role'] = $role;
    }

    // 1. Check if institution exists
    $mysqli = new mysqli($host, $db_user, $db_pass, 'institutions');
    if ($mysqli->connect_errno) {
        echo 'fail';
        exit;
    }
    $stmt = $mysqli->prepare('SELECT 1 FROM institutions WHERE institution_id = ? LIMIT 1');
    $stmt->bind_param('s', $institution_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        echo 'fail'; // Institution not found
        $stmt->close();
        $mysqli->close();
        exit;
    }
    $stmt->close();
    $mysqli->close();

    // 2. Check user in the correct schema/table
    $user_db = new mysqli($host, $db_user, $db_pass, $institution_id);
    if ($user_db->connect_errno) {
        echo 'fail';
        exit;
    }
    $table = '';
    $user_field = '';
    if ($role === 'Admin') {
        $table = 'admins';
        $user_field = 'username';
    } elseif ($role === 'Teacher') {
        $table = 'teachers';
        $user_field = 'username';
    } elseif ($role === 'Student') {
        $table = 'students';
        $user_field = 'idstudents';
    } else {
        echo 'fail';
        $user_db->close();
        exit;
    }
    $stmt2 = $user_db->prepare("SELECT password FROM $table WHERE $user_field = ? LIMIT 1");
    $stmt2->bind_param('s', $username);
    $stmt2->execute();
    $stmt2->store_result();
    if ($stmt2->num_rows === 0) {
        echo 'fail'; // User not found
        $stmt2->close();
        $user_db->close();
        exit;
    }
    $stmt2->bind_result($hashed_password);
    $stmt2->fetch();
    $stmt2->close();
    $user_db->close();

    // 3. Verify password (assuming Argon2i hash)
    if (password_verify($password, $hashed_password)) {
        $_SESSION['logged_in'] = 1;
        echo 'success';
    } else {
        echo 'fail'; // Password mismatch
    }
    exit;
}
?>
