<?php
session_start();
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
    header('Location: ../dashboard/');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../assets/css/login-styles.css">
</head>
<body>
    <div class="div-main">
        <input type="hidden" id="role" name="role" value="" />
        <span class="heading">Select your Role</span>
        <div class="selection">
            <span class="student-div" onclick="setRole('Student');loginPopup()">
                <img src="../assets/images/student.jpg"><br>
                Student
            </span>
            <span class="teacher-div" onclick="setRole('Teacher');loginPopup()">
                <img src="../assets/images/teacher.png"><br>
                Teacher
            </span>
            <span class="admin-div" onclick="setRole('Admin');loginPopup()">
                <img src="../assets/images/admin.png"><br>
                Admininstration
            </span>
        </div>
    </div>
    <div class="login-popup" id="login-popup">
        <div class="left">
            <img src="../assets/images/loginimg.png" alt="Illustration" />
          </div>
          <div class="right">
            <h1 class="name">ACRGS</h1>
            <h2>Login</h2>
            <form class="form" id="login-form">
              <label>Username/User ID</label>
              <input type="text" id="username" name="username" placeholder="Username/User ID" required />
              <label>Password</label>
              <div class="password-wrapper">
                <input type="password" id="password" name="password" placeholder="Password" required />
              </div>
              <a href="#" class="forgot" onclick="window.alert('Contact administrator')">Forgot Password ?</a>
              <label for="institution-id">Institution ID</label>
              <input type="text" id="institution-id" name="institution-id" placeholder="Enter Institution ID" required />
              <button type="submit">Sign in</button>
            </form>
          </div>
    </div>
</body>
<script>
    window.addEventListener('mouseup',function(event){
        var popup=document.getElementById('login-popup');
        if(popup.style.display!="none" && !popup.contains(event.target)){
            popup.style.display="none";
        }
    })
    function loginPopup(){
        popup=document.getElementById('login-popup');
        popup.style.display="flex";
    }
    function setRole(role) {
        document.getElementById('role').value = role;
    }
    document.getElementById('login-form').addEventListener('submit', function(e) {
        e.preventDefault();
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var institutionId = document.getElementById('institution-id').value;
        var role = document.getElementById('role').value;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '../ajax/authentication.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    if (xhr.responseText.trim() === 'success') {
                        window.location.href = '../dashboard/';
                    } else {
                        window.alert('Incorrect credentials');
                    }
                } else {
                    window.alert('Server error. Please try again.');
                }
            }
        };
        xhr.send('username=' + encodeURIComponent(username) + '&password=' + encodeURIComponent(password) + '&institution_id=' + encodeURIComponent(institutionId) + '&role=' + encodeURIComponent(role));
    });
</script>
</html>