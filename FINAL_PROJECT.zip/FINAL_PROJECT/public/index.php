<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automated Routine Generator</title>
    <link rel="stylesheet" href="assets/css/index-styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo"><img src="assets/images/logo.png" alt="Logo"></div>
        <div class="nav-links">
            <a href="#" onclick="scrollto(event,'headcontainer')">Home</a>
            <a href="#" onclick="scrollto(event,'midsection')">About us</a>
            <a href="#" onclick="scrollto(event,'team-container')">Contact us</a>
            <button class="sign-in" onclick="window.location='http://localhost/FINAL_PROJECT/public/login/index.php'">Sign in</button>
        </div>
    </nav>
    
    <div class="headcontainer" id="headcontainer">
        <div class="headtext">
           <h1> <span style="color: blue;">Automated</span> <br>
                                           <b>Routine</b> <br>
                <span style="color: blue;">Generator</span>
            </h1> 
            <p>An innovative tool designed to streamline the process of creating class<br/> schedules for educational institutions.</p>
        </div>
        <div class="headimage">
            <img src="assets/images/homeimg1.png" alt="Illustration">
        </div>
    </div>
    
    <div class="a1">
        <img src="assets/images/springarrowswne.png" alt="icon">
    </div>

    <div class="midsection" id="midsection">
        <div class="midimage">
            <img src="assets/images/homeimg2.png" alt="Illustration">
        </div>
            <div class="midtext">
                     <h1>What So <span style="color: orange;">Special</span><br/> <font color="orange" >About</font> Us?</h1>
                        <div class="feature">
                            <img src="assets/images/box_hearts.png" alt="Icon">
                                <div class="feature-text">
                                    <strong>Easy Time Table Generation</strong>
                                    <p>With the help of a single click</p>
                                </div>
                        </div><br>
                <div class="feature">
                    <img src="assets/images/box_jigsaw.png" alt="Icon">
                    <div class="feature-text">
                        <strong>Full GUI support</strong>
                        <p>No coding knowledge required</p>
                    </div>
                </div>
             </div>
             <div class="a2">
                <img src="assets/images/springarrowsenw.png" alt="icon">
            </div>
    </div>
    
    <section class="team">
        <div class="ufo1">
            <img src="assets/images/ufo.png" alt="icon">
        </div>
             <h2><font color="orange">Meet</font> Our <span class="highlight-blue"><font color="#05D8EB">TEAM!</font></span></h2>
             <p>Get a glimpse of our Team! 😄</p>
        <div class="team-container" id="team-container">
            <div class="team-member">
                <img src="assets/images/s.png" alt="Souradeep Roy">
                <h3>Souradeep Roy</h3>
                <p>DevOps & UI Designer</p>
            </div>
            <div class="team-member">
                <img src="assets/images/n.png" alt="Nilkantha Soren">
                <h3>Nilkantha Soren</h3>
                <p>Backend Developer & Database Manager</p>
            </div>
            <div class="team-member">
                <img src="assets/images/o.png" alt="Oishee Roy">
                <h3>Oishee Roy</h3>
                <p>Data Collection & Curation Lead</p>
            </div>
        </div>
        <div class="a3">
            <img src="assets/images/springarrownesw.png" alt="icon">
         </div>
         <div class="ufo2">
            <img src="assets/images/ufo.png" alt="icon">
        </div>
    </section>
    
    <section class="newsletter">
        <img src="assets/images/homeimg3.png" alt="Newsletter" class="newsletter-image">
       <div class="newsletter-text">
           <font color="#296BFA"><h2>Enroll yourself to get daily updates</h2>
            <p>Stay updated with our latest news and updates.</p></font>
            <div class="subscribe">
                <input type="email" placeholder="Email Address"/>
                <button>Send</button>
            </div>
        </div>
        <div class="a4">
            <img src="assets/images/springarrownwse.png" alt="icon">
         </div>
    </section>
    
    <footer class="footer">
        <div class="footer-logo">
            <img src="assets/images/logo.png" alt="Logo">
        </div>
        <div class="footer-content">
            <div class="footer-section">
                <h3>Institute</h3>
                <p>About Us</p>
                <p>How to work?</p>
                <p>Popular Course</p>
                <p>Service</p>
            </div>
            <div class="footer-section">
                <h3>Courses</h3>
                <p>Categories</p>
                <p>Online Course</p>
                <p>Other Courses</p>
            </div>
            <div class="footer-section">
                <h3>Support</h3>
                <p>FAQ</p>
                <p>Help Center</p>
                <p>Career</p>
                <p>Privacy</p>
            </div>
            <div class="footer-section">
                <h3>Contact Info</h3>
                <p>+0913-705-3875</p>
                <p>ElizabethJ@jourapide.com</p>
                <p>4808 Skinner Hollow Road</p>
                <p>Days Creek, OR 97429</p>
            </div>
        </div>
    </footer>
    <div class="footer-bottom">
       <hr/> <p>All Rights Reserved, 2025</p>
    </div>
</body>
<script>
    function scrollto(event,id){
        event.preventDefault();
        document.getElementById(id).scrollIntoView({
            behavior: "smooth",
            block : "center"
        });
    }
</script>
</html>
