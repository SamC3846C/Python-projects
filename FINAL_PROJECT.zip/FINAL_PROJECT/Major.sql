-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: 154
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `idadmin` int NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idadmin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'daitmadmin01',NULL,'$argon2i$v=19$m=65536,t=4,p=1$a2JteE1lT0hCZEVCcGhWNw$7ff1Pcz0Qbqvlc4k9uy1BWJ3PvWunVf5AoqVwUz0eX0','Daitm',NULL,'Admin01'),(2,'daitmadmin02',NULL,'$argon2i$v=19$m=65536,t=4,p=1$ajJMVDdUeTVsUUlVYmNjbA$TKZCDv5XQTIjk5jz3XPkjlZ0Ftf2iozsGbydOjRvQ6M','DAITM',NULL,'Admin02');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `idclasses` varchar(100) NOT NULL,
  `classname` varchar(100) DEFAULT NULL,
  `stream` varchar(20) DEFAULT NULL,
  `semester` varchar(3) DEFAULT NULL,
  `section` varchar(3) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `subjects` json DEFAULT NULL,
  `recess` json DEFAULT NULL,
  `time_table` json DEFAULT NULL,
  PRIMARY KEY (`idclasses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES ('1','BCA 2nd Sem Sec A','BCA','2','A','2024-25','[\"BCAC201\", \"BCAC291\", \"BCAC202\", \"BCAC292\", \"MIM201A\", \"GE4B-11\", \"AECC201\", \"SEC281\"]','[4, 1]','{\"fri\": [\"AECC201\", \"BCAC202\", \"MIM201A\", \"BCAC291\", \"BCAC291\", \"GE4B-11\"], \"mon\": [\"GE4B-11\", \"MIM201A\", \"BCAC202\", \"BCAC201\", \"SEC281\", \"AECC201\"], \"sat\": [\"SEC281\"], \"thu\": [\"BCAC291\", \"BCAC291\", \"BCAC202\", \"BCAC292\", \"BCAC292\", \"BCAC201\"], \"tue\": [\"BCAC292\", \"BCAC292\", \"GE4B-11\", \"BCAC201\", \"BCAC202\", \"MIM201A\"], \"wed\": [\"MIM201A\", \"BCAC292\", \"BCAC292\", \"SEC281\", \"GE4B-11\", \"BCAC201\"]}'),('2','BCA 2nd Sem Sec B','BCA','2','B','2024-25','[\"BCAC201\", \"BCAC291\", \"BCAC202\", \"BCAC292\", \"MIM201A\", \"GE4B-11\", \"AECC201\", \"SEC281\"]','[4, 1]','{\"fri\": [\"BCAC201\", \"BCAC292\", \"BCAC292\", \"AECC201\", \"BCAC202\"], \"mon\": [\"BCAC202\", \"GE4B-11\", \"MIM201A\", \"SEC281\", \"BCAC201\", \"MIM201A\"], \"sat\": [\"BCAC291\", \"BCAC291\"], \"thu\": [\"BCAC292\", \"BCAC292\", \"BCAC201\", \"SEC281\", \"MIM201A\", \"GE4B-11\"], \"tue\": [\"GE4B-11\", \"BCAC201\", \"BCAC202\", \"AECC201\", \"BCAC292\", \"BCAC292\"], \"wed\": [\"BCAC291\", \"BCAC291\", \"GE4B-11\", \"MIM201A\", \"BCAC202\", \"SEC281\"]}'),('3','BCA 4th Sem Sec A','BCA','4','A','2024-25','[\"BCAC401\", \"BCAC491\", \"BCAC402\", \"BCAC402\", \"BCAC403\", \"MIM401A\", \"MIM402A\", \"AECC401\"]','[4, 1]','{\"fri\": [\"BCAC491\", \"BCAC491\"], \"mon\": [\"MIM401A\", \"MIM402A\", \"BCAC401\", \"BCAC402\", \"BCAC403\", \"MIM401A\"], \"sat\": [], \"thu\": [\"MIM401A\", \"BCAC402\", \"AECC401\", \"BCAC401\", \"MIM402A\", \"BCAC403\"], \"tue\": [\"BCAC403\", \"BCAC402\", \"MIM402A\", \"BCAC491\", \"BCAC491\", \"MIM401A\"], \"wed\": [\"BCAC403\", \"MIM402A\", \"BCAC402\", \"BCAC491\", \"BCAC491\", \"AECC401\"]}'),('4','BCA 4th Sem Sec B','BCA','4','B','2024-25','[\"BCAC401\", \"BCAC491\", \"BCAC402\", \"BCAC402\", \"BCAC403\", \"MIM401A\", \"MIM402A\", \"AECC401\"]','[4, 1]','{\"fri\": [\"BCAC491\", \"BCAC491\"], \"mon\": [\"MIM402A\", \"BCAC402\", \"MIM401A\", \"BCAC403\", \"BCAC491\", \"BCAC491\"], \"sat\": [], \"thu\": [\"AECC401\", \"MIM401A\", \"MIM402A\", \"BCAC403\", \"BCAC402\", \"AECC401\"], \"tue\": [\"MIM401A\", \"BCAC403\", \"BCAC402\", \"MIM402A\", \"BCAC401\", \"BCAC403\"], \"wed\": [\"MIM401A\", \"BCAC491\", \"BCAC491\", \"BCAC401\", \"MIM402A\", \"BCAC402\"]}'),('5','BCA 6th Sem Sec A','BCA','6','A','2024-25','[\"BCAC601\", \"BCAC691\", \"BCAC602\", \"BCAD601E\", \"BCAD681\"]','[4, 1]','{\"fri\": [], \"mon\": [\"BCAD681\", \"BCAC601\", \"BCAD681\", \"BCAD601E\", \"BCAC602\", \"BCAC601\"], \"sat\": [\"BCAC691\", \"BCAC691\", \"BCAC691\", \"BCAC691\"], \"thu\": [], \"tue\": [\"BCAD681\", \"BCAD601E\", \"BCAC601\", \"BCAC602\", \"BCAD681\", \"BCAD601E\"], \"wed\": [\"BCAC602\", \"BCAD681\", \"BCAD601E\", \"BCAC601\", \"BCAC602\"]}'),('6','BCA 6th Sem Sec B','BCA','6','B','2024-25','[\"BCAC601\", \"BCAC691\", \"BCAC602\", \"BCAD601E\", \"BCAD681\"]','[4, 1]','{\"fri\": [\"BCAC601\"], \"mon\": [\"BCAD681\", \"BCAC691\", \"BCAC691\", \"BCAD681\", \"BCAD601E\", \"BCAD681\"], \"sat\": [], \"thu\": [\"BCAC602\", \"BCAC601\", \"BCAC601\"], \"tue\": [\"BCAC602\", \"BCAD681\", \"BCAD601E\", \"BCAD601E\", \"BCAC602\", \"BCAD681\"], \"wed\": [\"BCAD601E\", \"BCAC602\", \"BCAC601\"]}');
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `idstudents` varchar(45) NOT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `class_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idstudents`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES ('15401222019','Gourab',NULL,'Saha',NULL,'$argon2i$v=19$m=65536,t=4,p=1$V3FUQ1U5VEpMdFhJV1ovdw$97fh/rM82GiFqTqZ84DFi3DTrdbPXducMjbninz6M0o','4'),('15401222020','Debasmita',NULL,'Ganguly',NULL,'$argon2i$v=19$m=65536,t=4,p=1$cnppL3dHSTZoQXFjaUVMVg$qnqWTj0VvmrA/cZ7dVhpgOL7XiNTKT5JBbtheEkDOPs','6'),('15401222023','Souradeep',NULL,'Roy',NULL,'$argon2i$v=19$m=65536,t=4,p=1$VjNLT0lSTHdMYnkzNFUzbA$BjKNyDO+yPFrbu7o1lIwNllrM5SLJn2F6Y0927IjnoE','2'),('15401222029','Nilkantha',NULL,'Soren','nilkantha.soren@gmail.com','$argon2i$v=19$m=65536,t=4,p=1$S09GL1NqREM0VXo5QW1qZg$4oeD5hIofploIzmXmcJlcrt4OpSqbZT4SDaPWwaIm+Y','1'),('15401222032','Sudip','Kumar','Gharami',NULL,'$argon2i$v=19$m=65536,t=4,p=1$WlQzUjFOWmV3ZS83Wk9kdQ$ArQEyxOcA8od+nVq3OCtbdsIGaNfB9fXyekJnDnIsaw','5'),('15401222070','Oishee',NULL,'Roy',NULL,'$argon2i$v=19$m=65536,t=4,p=1$T25kZXhRWVBXTS9DTzJyag$p9E50B0oWrTKsR4kVAP8F/oLYGGwj1UN35KS6ZUt8A4','3');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subjects` (
  `idsubjects` int NOT NULL,
  `subject_code` varchar(45) DEFAULT NULL,
  `subject_name` varchar(100) DEFAULT NULL,
  `teacher_id` varchar(100) DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `frequency` int DEFAULT NULL,
  PRIMARY KEY (`idsubjects`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'BCAC201','Computer Architecture','anurupab',1,4),(2,'BCAC291','Computer Architecture Lab','anupamda',2,2),(3,'BCAC202','Basics of Web Design Using Html, CSS, Java Script','pinakshi',1,4),(4,'BCAC292','Basics of Web Design Using Html, CSS, Java Script Lab','nilimapa',2,3),(5,'MIM201A','Organizational Behaviour','subhrosm',1,4),(6,'GE4B-11','E-Commerce & M-Commerce','sasadmin',1,4),(7,'AECC201','Modern Indian Languages and Literature','upamagos',1,2),(8,'SEC281','IT Skills','maitreem',1,3),(9,'BCAC401','Database Management System','tanumoyn',1,2),(10,'BCAC491','Database Management System Lab','aditiban',2,3),(11,'BCAC402','Operating System','nabanita',1,4),(12,'BCAC403','Software Engineering','pinakshi',1,4),(13,'MIM401A','Human Resource Management','abhisark',1,4),(14,'MIM402A','E-Commerce','maitreem',1,4),(15,'AECC401','Society Culture and Human Behaviour','subhrosm',1,2),(16,'BCAC601','Unix and Shell Programming','nilimapa',1,4),(17,'BCAC691','Unix and Shell Programming Lab','aditiban',2,3),(18,'BCAC602','Cyber Security','nabanita',1,4),(19,'BCAD601E','E-Commerce','tanumoyn',1,4),(20,'BCAD681','Major Project','',1,5);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teachers` (
  `idteachers` int NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `aos` varchar(255) DEFAULT NULL,
  `time_table` json DEFAULT NULL,
  PRIMARY KEY (`idteachers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,'anurupab','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Anurupa',NULL,'Biswas',NULL,'','{\"fri\": [2, 0, 0, 0, 0, 0, 0], \"mon\": [0, 0, 0, 0, 1, 2, 0], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [0, 0, 2, 0, 0, 0, 1], \"tue\": [0, 2, 0, 0, 1, 0, 0], \"wed\": [0, 0, 0, 0, 0, 0, 1]}'),(2,'anupamda','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Anupam',NULL,'Das',NULL,'','{\"fri\": [0, 0, 0, 0, 1, 1, 0], \"mon\": [0, 0, 0, 0, 0, 0, 0], \"sat\": [2, 2, 0, 0, 0, 0, 0], \"thu\": [1, 1, 0, 0, 0, 0, 0], \"tue\": [0, 0, 0, 0, 0, 0, 0], \"wed\": [2, 2, 0, 0, 0, 0, 0]}'),(3,'pinakshi','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Pinakshi',NULL,'De',NULL,'','{\"fri\": [0, 1, 0, 0, 0, 2, 0], \"mon\": [2, 0, 1, 0, 4, 3, 0], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [0, 0, 1, 0, 4, 0, 3], \"tue\": [3, 4, 2, 0, 0, 1, 4], \"wed\": [3, 0, 0, 0, 0, 2, 0]}'),(4,'nilimapa','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Nilima',NULL,'Paul',NULL,'','{\"fri\": [6, 2, 2, 0, 0, 0, 0], \"mon\": [0, 5, 0, 0, 6, 0, 5], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [2, 2, 6, 0, 1, 1, 6], \"tue\": [1, 1, 5, 0, 6, 2, 2], \"wed\": [6, 1, 1, 0, 5, 6, 6]}'),(5,'subhrosm','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Subhro','Shankha','Mukherjee',NULL,'','{\"fri\": [0, 0, 1, 0, 0, 0, 0], \"mon\": [0, 1, 2, 0, 0, 0, 2], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [4, 0, 3, 0, 0, 2, 4], \"tue\": [0, 0, 0, 0, 0, 0, 1], \"wed\": [1, 0, 0, 0, 2, 0, 3]}'),(6,'sasadmin','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','',NULL,NULL,NULL,'','{\"fri\": [0, 0, 0, 0, 0, 0, 1], \"mon\": [1, 2, 0, 0, 0, 0, 0], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [0, 0, 0, 0, 0, 0, 2], \"tue\": [2, 0, 1, 0, 0, 0, 0], \"wed\": [0, 0, 2, 0, 0, 1, 0]}'),(7,'upamagos','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Upama',NULL,' Ghosh',NULL,'','{\"fri\": [1, 0, 0, 0, 2, 0, 0], \"mon\": [0, 0, 0, 0, 0, 0, 1], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [0, 0, 0, 0, 0, 0, 0], \"tue\": [0, 0, 0, 0, 2, 0, 0], \"wed\": [0, 0, 0, 0, 0, 0, 0]}'),(8,'maitreem','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Maitree ',NULL,'Majumdar',NULL,'','{\"fri\": [0, 0, 0, 0, 0, 0, 0], \"mon\": [4, 3, 0, 0, 2, 1, 0], \"sat\": [1, 0, 0, 0, 0, 0, 0], \"thu\": [0, 0, 4, 0, 2, 3, 0], \"tue\": [0, 0, 3, 0, 4, 0, 0], \"wed\": [0, 3, 0, 0, 1, 4, 2]}'),(9,'tanumoyn','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Tanumoy ',NULL,'Nag',NULL,'','{\"fri\": [0, 0, 0, 0, 0, 0, 0], \"mon\": [0, 6, 3, 0, 5, 6, 0], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [0, 0, 0, 0, 3, 0, 0], \"tue\": [6, 5, 6, 0, 6, 4, 5], \"wed\": [6, 6, 5, 0, 4, 0, 6]}'),(10,'aditiban','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Aditi ','Banerjee ','Mondal',NULL,'','{\"fri\": [3, 3, 0, 0, 4, 4, 0], \"mon\": [0, 6, 6, 0, 0, 4, 4], \"sat\": [5, 5, 0, 0, 5, 5, 0], \"thu\": [6, 6, 0, 0, 6, 6, 0], \"tue\": [0, 6, 6, 0, 3, 3, 0], \"wed\": [0, 4, 4, 0, 3, 3, 0]}'),(11,'abhisark','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Abhisekh ','','Sarkar',NULL,'','{\"fri\": [0, 0, 0, 0, 0, 0, 0], \"mon\": [3, 0, 4, 0, 0, 0, 3], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [3, 4, 0, 0, 0, 0, 0], \"tue\": [4, 0, 0, 0, 0, 0, 3], \"wed\": [4, 0, 0, 0, 0, 0, 0]}'),(12,'nabanita','$argon2i$v=19$m=65536,t=4,p=1$NVdUcU9XS0RPUEFNZElQbA$lBZbULfGjgtIWudeLcK5O6yJbD13hYv6SIgnkIu961U','Nabanita ',NULL,'Indra',NULL,'','{\"fri\": [0, 0, 0, 0, 0, 0, 0], \"mon\": [0, 4, 6, 0, 3, 5, 6], \"sat\": [0, 0, 0, 0, 0, 0, 0], \"thu\": [6, 3, 0, 0, 0, 4, 0], \"tue\": [6, 3, 4, 0, 5, 6, 6], \"wed\": [5, 6, 3, 0, 6, 5, 4]}');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-13 13:19:00
-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: institutions
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `institutions`
--

DROP TABLE IF EXISTS `institutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `institutions` (
  `idinstitutions` int NOT NULL,
  `institution_id` varchar(45) DEFAULT NULL,
  `institution_name` varchar(255) DEFAULT NULL,
  `slots_length` int DEFAULT NULL,
  `slots` int DEFAULT NULL,
  `start_time` int DEFAULT NULL,
  PRIMARY KEY (`idinstitutions`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institutions`
--

LOCK TABLES `institutions` WRITE;
/*!40000 ALTER TABLE `institutions` DISABLE KEYS */;
INSERT INTO `institutions` VALUES (1,'154','Dinabandhu Andrews Institute of Technology and Management',60,7,600);
/*!40000 ALTER TABLE `institutions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-13 13:19:00
